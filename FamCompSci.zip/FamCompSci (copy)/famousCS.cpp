/*
	Project Name: Famous Computer Scientists
	Author Name: Kevin George
	Date Written: March 16th, 2017
	Class: CSC100AA
	Brief Description: This program will take input from a text file and calculate an average score for certain computer scientists. The program will then explain something about each scientist that made them famous.
*/

#include<cstdlib>
#include<string>
#include<iostream>
#include<iomanip>
#include<algorithm>
#include<fstream>
#include <sstream>

using namespace std;
void stringBreak(string &fullString, string &first, string &last, string &t1, string &t2, string &t3, string &t4, string &t5);
int main()
{
	ifstream calcfile;
	ofstream outfile;
	string theWholeLine;
	string fname = "0";
	string lname = "0";
	string test1 = "0";
	string test2 = "0";
	string test3 = "0";
	string test4 = "0";
	string test5 = "0";
	double test1st;
	double test2nd;
	double test3rd;
	double test4th;
	double test5th;
	int i = 0;
	string calcfileName = "scores.txt";
	string outfileName = "CSExamReport.txt";
	calcfile.open(calcfileName);
	outfile.open(outfileName);
	if(calcfile.is_open())
	{
		if(outfile.is_open())
		{
			outfile << "Computer Scientist Exam Report" << endl;
			outfile << "------------------------------" << endl;
			cout << "Computer Scientist Exam Report" << endl;
			cout << "------------------------------" << endl;
			while(!calcfile.eof())
			{
				getline (calcfile, theWholeLine);
				theWholeLine = theWholeLine + " ";
				stringBreak(theWholeLine, fname, lname, test1, test2, test3, test4, test5);
				stringstream(test1) >> test1st;
				stringstream(test2) >> test2nd;
				stringstream(test3) >> test3rd;
				stringstream(test4) >> test4th;
				stringstream(test5) >> test5th;
				double average = (test1st + test2nd + test3rd + test4th+ test5th)/5;
				outfile << fname << lname << " has an exam average of " << fixed << setprecision(2)<< average << endl;
				cout << fname << lname << " has an exam average of " << fixed << setprecision(2)<< average << endl;
				i++;
			}
			outfile << "\nThere were " << i << " student records on file." << endl;
			cout << "\nThere were " << i << " student records on file." << endl;
			
			cout << "\nGrace Hopper - US Navy rear admiral, one of the first programmers on the Harvard 1 and created the first program compiler" << endl;
			cout << "Alan Kay - pioneered work on object-oriented programming and GUI's" << endl;
			cout << "John Backus - directed the development of FORTRAN " << endl;
			cout << "Sergey Brin - cofounder of Google developed the PageRank algorithm" << endl;
			cout << "Dennis Ritchie - created the C programming language and the UNIX OS" << endl;
			cout << "Brian Kernighan - contributed to the devlopment of UNIX" << endl;
			cout << "Grady Booch - developed UML, contributed to work in software architecture" << endl;
			
			cout << "\nAll files are closed and report is written. Farewell & Fair Weather" << endl;
			
		}
		else
		{
			cout << outfileName << " did not open" << endl;
		}
	}
	else
	{
		cout << calcfileName << " did not open" << endl;
	}
	calcfile.close();
	outfile.close();
	return 0;
}
void stringBreak(string &fullString, string &first, string &last, string &t1, string &t2, string &t3, string &t4, string &t5)
{
	int stringLength = fullString.length();
	int spacePoint = 0;
	int prevPoint = 0;
	int b = 1;
	string outString;
	for(int a = prevPoint; a <= stringLength; a++)
	{
		if(fullString[a] == ' ')
		{
			spacePoint = a;
			outString = fullString.substr(prevPoint, (spacePoint-prevPoint));
			//cout << outString << endl;
			switch(b)
			{
				case 1:
					first = outString;
					b++;
					break;
				case 2:
					last = outString;
					b++;
					break;
				case 3:
					t1 = outString;
					b++;
					break;
				case 4:
					t2 = outString;
					b++;
					break;
				case 5:
					t3 = outString;
					b++;
					break;
				case 6:
					t4 = outString;
					b++;
					break;
				case 7:
					t5 = outString;
					break;
				default:
					cout << "something broke" << endl;
					break;
			}
			prevPoint = spacePoint;
		}
	}
}

/* - Output

	Computer Scientist Exam Report
	------------------------------
	Grace Hopper has an exam average of 82.02
	Alan Kay has an exam average of 83.04
	John Backus has an exam average of 92.12
	Sergey Brin has an exam average of 85.50
	Dennis Ritchie has an exam average of 98.98
	Brian Kernighan has an exam average of 97.40
	Grady Booch has an exam average of 93.30

	There were 7 student records on file.

	Grace Hopper - US Navy rear admiral, one of the first programmers on the Harvard 1 and created the first program compiler
	Alan Kay - pioneered work on object-oriented programming and GUI's
	John Backus - directed the development of FORTRAN 
	Sergey Brin - cofounder of Google developed the PageRank algorithm
	Dennis Ritchie - created the C programming language and the UNIX OS
	Brian Kernighan - contributed to the devlopment of UNIX
	Grady Booch - developed UML, contributed to work in software architecture

	All files are closed and report is written. Farewell & Fair Weather
*/