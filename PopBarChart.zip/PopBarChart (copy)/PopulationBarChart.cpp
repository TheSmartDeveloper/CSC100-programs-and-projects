/*
	Project Name: Population Bar Chart
	Author Name: Kevin George
	Date Written: March 22nd, 2017
	Class: CSC100AA
	Brief Description: This program will take data from a text file and create a bar chart representing the data. This chart will be displayed in the terminal.
*/

#include<cstdlib>
#include<string>
#include<iostream>
#include<iomanip>
#include<algorithm>
#include<fstream>
#include <sstream>

using namespace std;
void stringBreak(string &fullString, string &date, string &population);
int main()
{
	ifstream data;
	string wholeLine;
	string years = "0";
	string people = "0";
	int theYears;
	int thePeople;
	string dataName = "people.txt";
	data.open(dataName);
	if(data.is_open())
	{
		cout << "PRAIRIEVILLE POPULATION GROWTH" << endl;
		cout << "(each * represents 1000 people)" << endl;
		while(!data.eof())
		{
			getline(data, wholeLine);
			wholeLine = wholeLine + " ";
			stringBreak(wholeLine, years, people);
			stringstream(years) >> theYears;
			stringstream(people) >> thePeople;
			int noOfStars = thePeople/1000;
			cout << "\n" << years << "\t";
			for(int aa = 1; aa <= noOfStars; aa++)
			{
				cout << "*"; 
			}
		}
		cout << "\n" << endl;
	}
	else
	{
		cout << dataName << " is not opened" << endl;
	}
	data.close();
	return 0;
}

void stringBreak(string &fullString, string &date, string &population)
{
	int stringLength = fullString.length();
	int spacePoint = 0;
	int prevPoint = 0;
	int b = 1;
	string outString;
	for(int a = prevPoint; a <= stringLength; a++)
	{
		if(fullString[a] == ' ')
		{
			spacePoint = a;
			outString = fullString.substr(prevPoint, (spacePoint-prevPoint));
			//cout << outString << endl;
			switch(b)
			{
				case 1:
					date = outString;
					b++;
					break;
				case 2:
					population = outString;
					break;
				default:
					cout << "something broke ¯\\_(ツ)_/¯ " << endl;
					break;
			}
			prevPoint = spacePoint;
		}
	}
}

/*
	PRAIRIEVILLE POPULATION GROWTH
	(each * represents 1000 people)

	1900	**
	1920	****
	1940	*****
	1960	*********
	1980	**************
	2000	******************
*/