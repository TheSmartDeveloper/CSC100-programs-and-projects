#ifndef BANKACCOUNT_H_INCLUDED__
#define BANKACCOUNT_H_INCLUDED__

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

class Bank
{
	private:
		int acctNumber;
		string name;
		double balance;
		
	public:
		Bank();
		Bank(int aNum, string aName, double amount);
		
		void setAcctNumber(int aNum);
		int getAcctNumber();
		
		void setName(string aName);
		string getName();
		
		double getBalance();
		
		void deposit(double amount);
		void withdraw(double amount);
		void displayData();
};
Bank::Bank()
{
	acctNumber = 0;
	name = "EMPTY";
	balance = 0.0;
}
Bank::Bank(int aNum, string aName, double amount)
{
	acctNumber = aNum;
	name = aName;
	balance = amount;
}
void Bank::setAcctNumber(int aNum)
{
	acctNumber = aNum;
}
int Bank::getAcctNumber()
{
	return acctNumber;
}
void Bank::setName(string aName)
{
	name = aName;
}
string Bank::getName()
{
	return name;
}
double Bank::getBalance()
{
	return balance;
}
void Bank::deposit(double amount)
{
	balance = balance + amount;
}
void Bank::withdraw(double amount)
{
	balance = balance - amount;
}
void Bank::displayData()
{
	cout << fixed << showpoint << setprecision(2);
	cout << "Account Information" << endl;
	cout << "-------------------" << endl;
	cout << "   Account Number: " << getAcctNumber() << endl;
	cout << "   Account Holder: " << getName() << endl;
	cout << "  Account Balance: " << getBalance() << endl;
}

#endif