//Ch 7 Classes Activity 4- Die Class  - Starting File.  Students download this file.
//Author : Kevin George
//Date: April 10, 2017
//Brief Description : This class represents
//    one die (singular of dice) with faces 
//    showing values between 1 and maxValue.  
//    Usually the maxValue is 6, but there 
//    are other dice with 8 sides, etc.  

#include <iostream>
#include <cstdlib>   //needed for rand
#include <ctime>     //needed for time function

using namespace std;

//Die class declaration

class Die
{
	//instance variables
	private: 
	  int faceValue;  //current value showing on die object
	  int maxValue;   //the maximum face value allowed

	public:
		Die();    //constructor.

		void setFaceValue(int value);  
		int getFaceValue();
		void roll();
		void displayData();

};

//method implementation section
Die::Die()
{
	faceValue = 1;
	maxValue = 6;
}
void Die::setFaceValue(int value)
{
	if(value >= 1 && value <= 6)
	{
		faceValue = value;
	}
}
int Die::getFaceValue()
{
	return faceValue;
}
void Die::roll()
{
	unsigned seed = time(0);
	srand(seed);
	faceValue = 1 + rand() % 6;
}
void Die::displayData()
{
	cout << fixed;
	cout << "\n\tFace Value: " << getFaceValue() << endl;
	cout << "\t Max Value: " << maxValue << endl;
}