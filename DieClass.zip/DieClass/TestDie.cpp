//Ch7 Classes Activity 4- Die Class.  TestDie.cpp 
//Starting File .  Students complete
//CSC100AA and CIS162AB
//Author : Kevin George
//Date: April 10, 2017
//description : Test the Die class.  Creates a die object and tests each of it's methods

#include <iostream>
#include <iomanip>

#include "Die.h"

using namespace std;
 
int main()
{
	//create a Die object called die1
	Die die1;
	cout << "Beginning state of die 1: ";
	//display the state of object die1 using displayData()
	die1.displayData();
	//set the faceValue of die1 to 4
 	die1.setFaceValue(4);
	cout << "State of die1 after setting faceValue to 4: " ;
	//display the state of object die1 
	die1.displayData();
	//set the faceValue of die1 to 15
	die1.setFaceValue(15);
	cout << "State of die1 after trying to set faceValue to 15: " ;
    //display of object die1 
	die1.displayData();
	//roll die1 
	die1.roll();
	cout << "The faceValue of die1 after a roll : " ;
	// display the faceValue of die1 
	die1.displayData();
	cout << endl;
	return 0;	
}

/* Expected output
	

*/