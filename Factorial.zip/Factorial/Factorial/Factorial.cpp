/*
	Program Id : Factorial.cpp
	Author : Kevin George
	Date : February 13th, 2017
	Class : CSC100
	Description: This program calculates the factorial of an inputed number (by the user)
*/

#include <iostream>
using namespace std;
int main()
{
	int userInput = 0;
	cout << "Calculating a Factorial\n" << endl;
	cout << "Enter a value between 1 and 10. (0 to quit): " << endl;
	cin >> userInput;

	for(int num = userInput; num > 0; num--)
	{
		userInput = userInput * (num--);
		cout << num << endl;
	}
	cout << "Factorial is" << userInput << endl;

	/*while (userInput != 0)
	{
		if (cin.fail())
		{
			cout << "Please use integers" << endl;
			cin >> userInput;
		}
		else if (userInput > 0 && userInput <= 10)
		{
			int num = userInput;
		}
	}*/

	system("pause");
	return 0;
}
